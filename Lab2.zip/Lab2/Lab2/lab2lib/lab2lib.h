void Task1();
bool is_sorted(int arr[], int length);

void Task2();
bool is_palindrome(char txt[]);

void Task3();
void array_row_cols(int arr[256][256], int cols, int rows);

void Task4();
void swap_sort(int &a, int &b, int &c, bool order);

void Task5();
void shrink_array(int *arr, int length);

void Task6();
